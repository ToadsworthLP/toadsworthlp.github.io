//Datenbankzeug
var HttpClient = function() {
	this.get = function(aUrl, aCallback) {
	    var anHttpRequest = new XMLHttpRequest();
	    anHttpRequest.onreadystatechange = function() { 
	        if (anHttpRequest.readyState == 4 && anHttpRequest.status == 200)
	            aCallback(anHttpRequest.responseText);
	    }

	    anHttpRequest.open( 'GET', aUrl, true );            
	    anHttpRequest.send();
	}
}

//Box-Visualisierung
var availableSymbol = "&#9632;";
var notAvailableSymbol = "&#9633;";
function makeBoxes(current, maximum, charsBeforeLinebreak){
	var output = "";
	var lineBreaker = 2;
	for (var i = current; i > 0; i--) {
		if(lineBreaker > charsBeforeLinebreak){
			output+=availableSymbol+"<br>";
			lineBreaker=2;
		}else{
			output+=availableSymbol;
			lineBreaker++;
		}
	}
	for (var i = maximum-current; i > 0; i--) {
		if(lineBreaker > charsBeforeLinebreak){
			output+=notAvailableSymbol+"<br>";
			lineBreaker=2;
		}else{
			output+=notAvailableSymbol;
			lineBreaker++;
		}
	}
	return output;
}