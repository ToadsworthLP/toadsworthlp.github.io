<?php
//Name der Datenbank
$database = "cine4you";

// Verbindung zum Datenbankserver 
$conn = new mysqli("localhost", "root", "", $database);

// Verbindung überprüfen
if ($conn->connect_error) {
    die("Error:" . $conn->connect_error);
} 

$titleQuery = "SELECT * FROM `products`";
$rs = $conn->query($titleQuery);

// Schleifendurchlauf durch die Variable $rs
while($zeile = mysqli_fetch_array($rs)) {
	//Gibt den Titel in der aktuellen Zeile aus
	echo $zeile["title"]."|";
}
 
// Schließt die Datenbankverbindung
$conn->close();
?>