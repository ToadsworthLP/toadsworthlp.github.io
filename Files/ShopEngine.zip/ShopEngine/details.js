var detailsDiv;
var detailsArray = new Array ();
var title = window.location.hash.substring(1);

window.onload = function(){
	getDetails();
}

//Holt die Produkttitel aus der Datenbank
function getDetails(){
	detailsDiv = document.getElementById("details");
	var client = new HttpClient();
	
	client.get("getDetails.php?title="+title, function(response) {
	    detailsArray['title'] = response.split("|")[0];
	    detailsArray['description'] = response.split("|")[1];
		detailsArray['price'] = response.split("|")[2];
		detailsArray['pictureUrl'] = response.split("|")[3];
		detailsArray['maxStored'] = response.split("|")[4];
		detailsArray['leftStored'] = response.split("|")[5];
		displayDetails();
	}); 
}

function displayDetails(){
	var output = "";
	
	/* DEBUG Zeigt die Details im Rohformat an
	for(key in detailsArray){
		output += key + " : " + detailsArray[key] + "<br>";
	}
	*/

	document.getElementById("title").innerHTML = detailsArray['title'];

	var picture = document.createElement("picture");
	picture.innerHTML = "<img src='"+detailsArray['pictureUrl']+"'><br>";
	detailsDiv.appendChild(picture);

	var description = document.createElement("description");
	description.innerHTML = detailsArray['description']+"<br>";
	detailsDiv.appendChild(description);

	var stored = document.createElement("stored");
	stored.innerHTML = detailsArray['leftStored']+"/"+detailsArray['maxStored']+" noch zu haben!<br>";
	detailsDiv.appendChild(stored);

	var storedVisualization = document.createElement("storedVisualization");
	storedVisualization.innerHTML = makeBoxes(detailsArray['leftStored'], detailsArray['maxStored'], 10)+"<br>";
	detailsDiv.appendChild(storedVisualization);

	addOrderButton();
}

function addOrderButton(){
	//Ermöglicht Bestellung nur, wenn noch mindestens 1 da ist
	if(detailsArray['leftStored'] > 0){
		var orderButton = document.createElement("order");
		orderButton.innerHTML = "<input class='order' id='order' type='button' value='Bestellen ("+detailsArray['price']+" Euro)' onclick='orderSubmitted();'/>";
		detailsDiv.appendChild(orderButton);
	}else{
		var orderButton = document.createElement("order");
		orderButton.innerHTML = "<input class='noOrder' id='noOrder' type='button' value='Keine mehr da!'/>";
		detailsDiv.appendChild(orderButton);
	}
}

function orderSubmitted(){
	var client = new HttpClient();
	
	client.get("order.php?product="+title, function(response) {
	    alert(response);
	    location.reload();
	}); 
}