window.onload = function(){
	addTitles();
}

//Holt die Produkttitel aus der Datenbank
function addTitles(){
	var client = new HttpClient();
	var productsDiv = document.getElementById("products");
	
	client.get("getTitles.php", function(response) {
	    var productArray = response.split("|");
	    
	    //Fügt jedes (außer das leere, letzte) Ergebnis in das productsDiv ein
	    for (var i = productArray.length - 2; i >= 0; i--) {
	    	var productNode = document.createElement("product"+i);
	    	productNode.innerHTML = "<a href='details.html#"+productArray[i]+"'>"+productArray[i]+"</a><br>";
	    	productsDiv.appendChild(productNode);
	    }
	}); 
}