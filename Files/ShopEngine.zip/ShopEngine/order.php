<?php
//Name der Datenbank
$database = "cine4you";

// Verbindung zum Datenbankserver 
$conn = new mysqli("localhost", "root", "", $database);
$left = 0;

// Verbindung überprüfen
if ($conn->connect_error) {
    die("Error:" . $conn->connect_error);
} 

$leftQuery = "SELECT * FROM `products`";
$rs = $conn->query($leftQuery);

// Schleifendurchlauf durch die Variable $rs
while($zeile = mysqli_fetch_array($rs)) {
	if ($zeile["title"] == $_GET["product"]) {
		$left = $zeile["leftStored"];
		$left = --$left;
	}
}
	
$updateQuery = "UPDATE `products` SET leftStored=".$left." WHERE title='".$_GET["product"]."'";

if ($conn->query($updateQuery) === TRUE) {
    echo "Bestellung erfolgreich!";
} else {
    echo "Ein Fehler ist aufgetreten.";
}
 
// Schließt die Datenbankverbindung
$conn->close();
?>